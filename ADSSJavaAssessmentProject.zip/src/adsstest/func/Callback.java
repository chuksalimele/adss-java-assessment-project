
package adsstest.func;

/**
 *
 * @author Chukwudi Alimele
 * @param <T>
 */
public interface Callback<T> {
    void call(T param);
}
