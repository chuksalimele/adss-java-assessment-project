
package adsstest.feed;

/**
 *
 * @author Chukwudi Alimele
 */
public class MsgType {
    public static String MSG_TYPE_A = "A";
    public static String MSG_TYPE_B = "B";
    public static String MSG_TYPE_C = "C";
}
