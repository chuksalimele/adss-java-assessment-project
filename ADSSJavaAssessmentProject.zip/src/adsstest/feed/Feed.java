
package adsstest.feed;

/**
 * Service that will declare the contract for service implementation
 * @author Chukwudi Alimele
 */
public interface Feed {
    
    /**
     * This is used to read the field 
     * 
     * @return 
     */
    String getMessage();
}
