
package adsstest.listeners;

import adsstest.feed.Message;

/**
 *
 * @author Chukwudi Alimele
 */
public interface MessageListener {    
    void onMessage(Message msg);
}
