# adss-java-assessment-project
An assessment project from ADSS to test my Java Skrill
